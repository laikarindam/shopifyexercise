({
	
    doInit : function(component, event, helper){
        helper.getjobApplicationPositionHelper(component, event, helper);
    },
    
    handleApplicationEvent : function(component, event, helper) {
		var posid = event.getParam("positionid");
        console.log(posid);
        
        helper.getjobApplicationPositionHelper(component, event, helper, posid);
	},    
    
    posnavigate : function(component, event, helper){
        var postarget = event.target;
        var postargetid = event.target.getAttribute('data-index');
        debugger;
        //helper.getjobApplicationPositionHelper(component, event, helper);
    },
    
    applicantnavigate : function(component, event, helper){
        var Applicanttarget = event.target;
        var Applicanttargetid = event.target.getAttribute('data-index');
        debugger;
        
        var appEvent = $A.get("e.c:SHOP_ApplicantDetailsEvt");
		appEvent.setParams({ "jobapplicantid" : Applicanttargetid });
		appEvent.fire();
        //helper.getjobApplicationPositionHelper(component, event, helper);
    }
})