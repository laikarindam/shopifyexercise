({
	getjobApplicationPositionHelper : function(component, event, helper, posid) {
		var action = component.get("c.getjobApplicationPosition");
        
        var recordid = component.get("v.recordId");
        action.setParams({positionId : posid, loadAccountId : recordid});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if ( state === "SUCCESS") {
                var resultList = response.getReturnValue();
                console.log(resultList);
                component.set('v.jobApplicationWrap', resultList.lstPositionRelatedApplicationWrap);
            }
            else {
                console.log(response.getError());
            }
        });
        $A.enqueueAction(action);
	}
})