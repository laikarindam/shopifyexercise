({
	getDepartmentRelatedPositionHelper : function(component, event, helper) {
        
        var action = component.get("c.getDepartmentRelatedPosition");
        
        //var recordid = component.get("v.recordId");
        var recordid = '0015f0000054Vx4AAE';
        action.setParams({departmentID : recordid});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if ( state === "SUCCESS") {
                var resultList = response.getReturnValue();
                /*resultList.lstDepartmentRelatedPositionWrap.forEach(function(record){
                    record.posLink = '/'+record.posId;
                });*/
                console.log(resultList);
                component.set('v.posdata', resultList.lstDepartmentRelatedPositionWrap);
            }
            else {
                console.log(response.getError());
            }
        });
        $A.enqueueAction(action);              
	}
})