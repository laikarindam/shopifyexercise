({
	doInit : function(component, event, helper) {
        var actions = [
            { label: 'View', name: 'View_Position' }
        ]
		component.set('v.poscolumns',[
            //{label:'Job Name', fieldName:'posLink', type:'url', typeAttributes: { label: { fieldName: 'posName' }, target: '_blank'}},
            {label:'Job', fieldName:'posName', type:'text'},
            {label:'Status', fieldName:'posStatus', type:'text'},
            {label:'Open', fieldName:'posOpenDate', type:'date', typeAttributes: { year: "numeric", month: "2-digit", day: "2-digit"}},
            {label:'Location', fieldName:'posLoc', type:'text'},
            {label: 'Actions', initialWidth: 100, type: 'action', typeAttributes: {rowActions: actions}}
        ]);
        
        helper.getDepartmentRelatedPositionHelper(component, event, helper);
	},
    
    handleRowAction : function(component, event, helper) {
        debugger;
        var recId;
        var actionName = event.getParam('action').name;
        if(actionName == 'View_Position'){
            recId = event.getParam('row').posId;
        }
        debugger;
        
        var appEvent = $A.get("e.c:SHOP_PositionDetailsEvt");
		appEvent.setParams({ "positionid" : recId });
		appEvent.fire();
    }
})