({
	doInit : function(component, event, helper) {
		
        //component.set("v.recordId","0015f0000054VK6AAM");
	},
    
    handleApplicationEvent : function(component, event, helper) {
        var jobapplid = event.getParam("jobapplicantid");
        console.log(jobapplid);
		component.set("v.recordId",jobapplid);
	},
})